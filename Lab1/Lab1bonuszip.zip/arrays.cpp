#include <iostream>
#include <iomanip>
using namespace std;

double  mean(int arr[],int size);
double  mean2(int* arr,int size);

int main(){
	double  mean1 = 0;
	double meantwo = 0;
	int size = 0;
	//Entering the size of array

	cout << "Enter the size of the array you want? " << endl;
	cin >> size;

	//array "arr" is made with the size user wants

	int arr[size];
	cout << "Enter " << size << " numbers." << endl;
	for(int i = 0; i < size; i++){
	cin >> arr[i];
	
	}

	mean1 = mean(arr,size);	
	meantwo = mean2(arr,size);
	cout << "The mean of the array using function mean is  " << mean1 << endl;
	cout << "The mean of the array using function mean2 is " << meantwo << endl; 
}	


	double mean(int arr[],int size){
	double  sum = 0;
	double mean = 0;	
	
	for(int i = 0;i < size;i++){
	 sum += arr[i];
	}		
	mean = double(sum/size);
	return mean;  
}




double  mean2(int* arr,int size){

	cout << fixed <<  showpoint << setprecision(2) << endl;
	double  sum = 0;
	double mean2  = 0;	

	for(int i = 0;i < size;i++){
	sum += *(arr + i);
	
	}
	mean2 =	double(sum/size);
	

	return mean2;
