#include <iostream>
using namespace std;

struct Node{
  int value;
  Node* next;

  Node(){
    value = 0;
    next = NULL;
  }
  Node(int n){
    value = n;
    next = NULL;
  }
};

void deleteList(Node *head);

int size(Node* head);


void print(Node* head);
void rvPrint(Node* head);

Node* sortedInsert(Node* head, int size);

Node *append(Node *fhead, Node *shead);

// still need to make remove function
// and need to make a function to reverse the
// list

Node *rmNode(Node *head,int n);

Node *rev(Node *head);
// needs looking at
int main(){
  Node *head = new Node(7);

 head = sortedInsert(sortedInsert(sortedInsert(sortedInsert(head,15),4),12),10);

 cout <<"Head has been inserted and sorted.\n";

 print(head);

  cout << endl;

  cout <<" Head printed backwards.\n";

  rvPrint(head);

  cout << endl;

  cout <<"Removing 12\n";

  Node *rm = rmNode(head,12);

  print(rm);

  cout <<"Backwards hean\n";

  head = rev(head);

  print(head);

  cout << endl;

  cout <<"Sorted insert in head one\n";

  Node *head1 = new Node(9);

  head1 = sortedInsert(sortedInsert(sortedInsert(sortedInsert(head,1),14),13),2);

  print(head1);

  cout <<"Append first head to head one \n";

  head1 = append(head1,head);

  print(head1);

  deleteList(rm);

  deleteList(head1);



return 0;
}
void deleteList(Node *head){
  if(!head){
    return;
    deleteList(head->next);
    delete head;
}
}
int size(Node* head){
  if(!head){
    return 0;
  }
  return size(head->next)+1;
}


void print(Node* head){
  if(!head){
    return;
  }
    cout << head -> value << endl;
    return print(head -> next);
}
void rvPrint(Node* head){
  if(!head){
    return;
  }
  rvPrint(head -> next);
  cout << head -> value << endl;
}

Node* sortedInsert(Node* head, int size){
  if(!head){
    Node *rtn = new Node(size);
    return rtn;

  }else if(size < head -> value){
    Node* n = new Node(size);
    n -> next = head;

    return n;
  }else if(!head -> next){
    head -> next = new Node(size);

    return head;
  }else if(head -> next -> value > size){
    Node* n = new Node(size);
    n -> next = head -> next;
    head -> next = n;

    return head;
  }
  sortedInsert(head -> next, size);
  return head;
}

Node *append(Node *fhead, Node *shead){
  if(!fhead){
    fhead = shead;
    cout << "Hello " << endl;
    return fhead;
  }else if(!fhead -> next){
    fhead -> next = shead;
    cout << "Hello 2" << endl;
    return fhead;
  }
  append(fhead-> next, shead);
  return fhead;
}

// still need to make remove function
// and need to make a function to reverse the
// list

Node *rmNode(Node *head,int n){
  if(!head){
    cout << n << " is not in the list\n";
    return head;
  }else if(head -> next && head -> next -> value == n){
    Node *t = head -> next;
    Node *t1 = new Node(t -> value);
    head -> next  = head -> next -> next;
    delete t;
    return t1;
  }else if(head -> value == n){
    Node *t = head;
    Node *t2 = new Node(t -> value);
    head = head -> next;
    delete t;
    return t2;
  }
  Node *t3 = rmNode(head -> next , n);
  return t3;
}

Node *rev(Node *head){

  if(!head){
    return NULL;

  } else if(!head -> next){
    return head;
  }
  Node* last = rev(head -> next);
  last = append(last,head);
  head -> next = NULL;
  return last;
}
